// prepear WifFi
const char* ssid = "WLAN-Name";            // Replace with your
const char* password = "Password";          // WiFi credentials
const char* aDTU = "http://xxx.xxx.xxx.xxx/api/livedata/status?inv=138290780654.json"; //   Inverter Adressen anpassen
const char* bDTU = "http://xxx.xxx.xxx.xxx/api/livedata/status?inv=138291500432.json"; // 
const char* shelly = "http://xxx.xxx.xxx.xxx/status"; //  
const char* shellyDelete = "http://xxx.xxx.xxx.xxx/reset_data"; //Löchen der Shelly-Daten für einen neuen Tag
const char* iskra = "http://xxx.xxx.xxx.xxx/cm?cmnd=status%2010"; //  
const char* iskra2 = "http://xxx.xxx.xxx.xxx/cm?cmnd=state"; 
//externer ESP32-Wettersensor mit Display//
const char* AussenTemp   = "http://xxx.xxx.xxx.xxx/Status";
String apikey         = "d5a94a1d1eddd125af353277cd30ba84"; //neu ab 21/2025
// Use your own API key by signing up for a free developer account at https://openweathermap.org/
//String apikey         = "1e21f58225f9c4cfb1859dee54476716";                  // See: https://openweathermap.org/  // It's free to get an API key, but don't take more than 60 readings/minute!
const char server[] = "api.openweathermap.org";
String LAT              = "54.61";                         // Home location Latitude
String LON              = "5.85";                         // Home location Longitude
String Country          = "DE";                            // Your _ISO-3166-1_two-letter_country_code country code, on OWM find your nearest city and the country code is displayed
String Language         = "DE";                            // NOTE: Only the weather description is translated by OWM
String Hemisphere       = "north";                         // or "south"  
String Units            = "M";                             // Use 'M' for Metric or I for Imperial 
const char* Timezone    = "CET-1CEST,M3.5.0,M10.5.0/3";  // Choose your time zone from: https://github.com/nayarsystems/posix_tz_db/blob/master/zones.csv 
const char* ntpServer   = "0.europe.pool.ntp.org";             // Or, choose a time server close to you, but in most cases it's best to use pool.ntp.org to find an NTP server
int   gmtOffset_sec     = 0;    // UK normal time is GMT, so GMT Offset is 0, for US (-5Hrs) is typically -18000, AU is typically (+8hrs) 28800
int  daylightOffset_sec = 7200; // In the UK DST is +1hr or 3600-secs, other countries may use 2hrs 7200 or 30-mins 1800 or 5.5hrs 19800 Ahead of GMT use + offset behind - offset

